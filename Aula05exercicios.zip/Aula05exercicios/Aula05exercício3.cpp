#include <stdio.h>

int main(){
	float notas[5][4];
	float media[5],soma;
	int i,j;
	int alunoMaior = 0, alunoMenor = 0;
	
	//Entrada de dados
	for( i = 0;i < 5; i++){
		soma = 0;
		printf("\nDigite as 4 notas (0 a 10) do aluno %d:\n", i + 1);
		for( j =0; j < 4; j++){
			printf("Nota %d: ", j + 1);
		    scanf("%f", &notas[i][j]);
		    soma += notas[i][j];
	  }
	  media[i] = soma/4.0;
	}
	
	//Encontrar menor m�dia
	for(i = 0; i < 5; i++){
		if(media[i] > media[alunoMaior]){
			alunoMaior = i;
		}
		if(media[i] < media[alunoMenor]){
			alunoMenor = i;
		}
	}
	printf("\n--- RESULTADO FINAL ---\n");
	for(i = 0; i < 5; i++){
		const char *status;
		status = (media[i] >= 7) ? "Aprovado!" 
			           : (media[i] >= 5) ? "Recuperacao!" :
			           "Reprovado";
	printf("Aluno %d - Media: %.2f - %s\n", i + 1,media[i], status);
	}
	printf("\nAluno com MAIOR Media: Aluno %d (%.2f)\n", alunoMaior + 1, media[alunoMaior]);
	printf("Aluno com MENOR Media: Aluno %d (%.2f)\n", alunoMenor + 1, media[alunoMenor]);
	
	return 0;
}
