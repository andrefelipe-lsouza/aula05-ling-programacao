#include <stdio.h>

int main(){
	float preco [5];//vetor que vai guardar os pre�os
	float desconto, preco_final;//variavel que armazena pre�o final e o dsconto 
	int i;
	
	//Entrada de dados
	for (i = 0; i < 5; i++){
		printf("Digite o preco do produto %d: R$ ", i + 1);
		scanf("%f", &preco[i]);
	}
	
	//cabecalho de saida
	printf("\n%-15s %-15s %-15s\n", "Preco original", "Desconto", "Preco final");
	
	//Processamento e sa�da
	for(i = 0; i < 5; i++){
		if (preco[i] > 100){
			desconto = preco[i] * 0.10;//10% de desconto
		}else if (preco[i] >= 50 && preco[i] <= 100){
			desconto = preco[i] * 0.05;//%5 de desconto
		}else {
			desconto = 0.0;//sem desconto
		}
		preco_final = preco[i] - desconto;
		printf("R$ %-12.2f R$ %-12.2f R$ %-12.2f\n",preco[i], desconto, preco_final);//ipress�o em 12 colunas com 2 casas decimais
	}
	
	return 0;
}
