#include <stdio.h>

int main(){
	int numeros[10];
	int paresPositivos = 0; //inicializar as variaveis para evitar erros
	int imparesNegativos = 0;
	int multiplos = 0;
	int i;
	int n;
	
	//L� os 10 numeros digitados pelo usuario
	for(i = 0; i < 10; i++){
		printf("Digite um numero %d:", i + 1);
		scanf("%d", &numeros[i]);
	}
	
	//Processamento
	for(i = 0;i < 10; i++){
		n = numeros[i];
	
	if (n % 2 == 0 && n > 0) {//verifica se o numero � par
            paresPositivos++;
	}
	if (n % 2 != 0 || n < 0){//verifica se o numero � impar ou negativo
		imparesNegativos++;
	}
	if (n % 3 == 0 && n % 5 == 0){//verifica se o numero � multiplo de 3 e 5 ao mesmo tempo
		multiplos++;
	}
  }
  //Sa�da de dados
  printf("\nQuantidade de numeros pares e positivos: %d", paresPositivos);
  printf("\nQuantidade de numeros impares ou negativos: %d", imparesNegativos);
  printf("\nQuantidade de numeros multiplos de 3 e 5: %d\n", multiplos);
  
  return 0;
}
